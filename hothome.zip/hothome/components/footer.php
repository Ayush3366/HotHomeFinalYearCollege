<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:1234567890"><i class="fas fa-phone"></i><span>(416) 291-5155</span></a>
         <a href="#"><i class="fas fa-envelope"></i><span>Loyalistcollege@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span> 4000 Victoria Park Ave, Toronto </span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>Home</span></a>
         <a href="about.php"><span>About</span></a>
         <a href="contact.php"><span>Contact</span></a>
      </div>

      <div class="box">
         <a href="#"><span>Facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>Linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>Instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; Copyright @ <?= date('Y'); ?> by <span>Loaylist Colllege in Toronto</span> | All rights reserved!</div>

</footer>

<!-- footer section ends -->